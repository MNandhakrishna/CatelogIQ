Django Application for Text Log Analytics
